-- phpMyAdmin SQL Dump
-- version 4.7.6
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 15, 2017 at 03:52 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restclient`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `CustomerID` int(11) NOT NULL,
  `CustomerName` varchar(100) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `PhoneNumber` text NOT NULL,
  `Date` text NOT NULL,
  `StartTime` int(11) NOT NULL,
  `EndTime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CustomerID`, `CustomerName`, `PhoneNumber`, `Date`, `StartTime`, `EndTime`) VALUES
(19, 'محمود رئیسی', '09171980161', '24/09/1396', 13, 15),
(20, 'سلمان رئیسی', '09171981069', '26/09/1396', 21, 22);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `OrderID` int(11) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  `FoodName` varchar(100) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `FoodNumber` int(11) NOT NULL,
  `FoodPrice` int(11) NOT NULL,
  `RestaurantID` int(11) NOT NULL,
  `Reported` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `CustomerID`, `FoodName`, `FoodNumber`, `FoodPrice`, `RestaurantID`, `Reported`) VALUES
(109, 19, 'کباب بختیاری', 4, 20000, 1, 1),
(110, 19, 'کباب برگ', 2, 23000, 1, 1),
(111, 19, 'پیتزا مکزیکی', 2, 25000, 2, 1),
(112, 19, 'پیتزا مرغ و قارچ', 2, 26000, 2, 1),
(113, 19, 'نوشابه پپسی قوطی', 2, 1500, 3, 1),
(114, 19, 'نوشابه کوکاکولا قوطی', 3, 1500, 3, 1),
(115, 20, 'جوجه کباب', 2, 15000, 1, 1),
(116, 20, 'کباب بختیاری', 3, 20000, 1, 1),
(117, 20, 'پیتزا سبزیجات', 3, 22000, 2, 1),
(118, 20, 'پیتزا مکزیکی', 3, 25000, 2, 1),
(119, 20, 'نوشابه پپسی خانواده', 2, 2500, 3, 1),
(120, 20, 'دوغ خانواده', 1, 2000, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `ReportID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `FoodName` varchar(100) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `Number` int(11) NOT NULL DEFAULT '0',
  `TotalPrice` int(11) NOT NULL DEFAULT '0',
  `RestaurantID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`ReportID`, `Date`, `FoodName`, `Number`, `TotalPrice`, `RestaurantID`) VALUES
(25, '0000-00-00', 'کباب بختیاری', 7, 140000, 1),
(26, '0000-00-00', 'کباب برگ', 2, 46000, 1),
(27, '0000-00-00', 'پیتزا مکزیکی', 5, 125000, 2),
(28, '0000-00-00', 'پیتزا مرغ و قارچ', 2, 52000, 2),
(29, '0000-00-00', 'نوشابه پپسی قوطی', 2, 3000, 3),
(30, '0000-00-00', 'نوشابه کوکاکولا قوطی', 3, 4500, 3),
(31, '0000-00-00', 'جوجه کباب', 2, 30000, 1),
(32, '0000-00-00', 'پیتزا سبزیجات', 3, 66000, 2),
(33, '0000-00-00', 'نوشابه پپسی خانواده', 2, 5000, 3),
(34, '0000-00-00', 'دوغ خانواده', 1, 2000, 3);

-- --------------------------------------------------------

--
-- Table structure for table `reservedtable`
--

CREATE TABLE `reservedtable` (
  `ReserveID` int(11) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  `Type` varchar(100) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `Number` int(11) NOT NULL,
  `TotalPrice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservedtable`
--

INSERT INTO `reservedtable` (`ReserveID`, `CustomerID`, `Type`, `Number`, `TotalPrice`) VALUES
(28, 19, 'چهار نفره', 1, 20000),
(29, 20, 'شش نفره', 1, 30000);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` text NOT NULL,
  `FullName` varchar(100) CHARACTER SET utf32 COLLATE utf32_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `UserName`, `Password`, `FullName`) VALUES
(1, 'raeisi', '$2y$10$A23aY.sYuOAhz0t5DaxYP.xAEAP2CrKHcjlY72IZZmBQP15gPULAW', 'محمود رئیسی');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`CustomerID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`OrderID`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`ReportID`);

--
-- Indexes for table `reservedtable`
--
ALTER TABLE `reservedtable`
  ADD PRIMARY KEY (`ReserveID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `OrderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `ReportID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `reservedtable`
--
ALTER TABLE `reservedtable`
  MODIFY `ReserveID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
