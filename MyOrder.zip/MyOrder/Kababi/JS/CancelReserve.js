function FCancelReserve(x) {
    var y = "";
    y += 'foodnum' + x;
	document.getElementById(y).value = 0;
}
		
function DCancelReserve(x) {
	var y = "";
	y += 'drinknum' + x;
	document.getElementById(y).value = 0;
}