var j = 0;
var num = "";

while (nums[j]) {
    num = nums[j];
    var SelectNum = '';
    for(i = 0; i <= 100; i++) {
        SelectNum += '<option value=' + i + '>' + i + '</option>';
    }
    document.getElementById(num).innerHTML = SelectNum;
    j++;
}