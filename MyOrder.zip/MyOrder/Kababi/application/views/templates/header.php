<!DOCTYPE html>

<html lang="fa" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $title; ?></title>
    <?php
        if($title == 'سفارشات') {
            echo '<meta http-equiv="refresh" content="30">';
        } 
        if($title == 'گزارش') {
            echo '<meta http-equiv="refresh" content="30">';
        }
    ?>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/<?php echo $cssfile; ?>.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/jquery-ui-1.8.14.css"  />

    <script type="text/javascript" src="<?php echo base_url(); ?>JS/jquery-1.6.2.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>JS/jquery.ui.datepicker-cc.all.min.js"></script>
    <script type="text/javascript">
	    $(function() {
	        $("#datepicker").datepicker({
	            showOn: 'button',
	            buttonImage: '<?php echo base_url(); ?>images/cal.png',
	            buttonImageOnly: true
	        });
	    });
    </script>

    
</head>
<body>
