<footer>
  <section class="copyright">
      <p>Copyright &copy 2017 <br/>
      All rights reserved</p>
  </section>
</footer>
</body>
</html>
