<section class="CustomerInfo">
  <?php
    echo "<p>خوش آمدید  " . $_SESSION['CustomerName'] . "</p>";
    echo "<p>شماره میز شما: " . $_SESSION['CustomerTable'] . "</p>";
  ?>
</section>
