<section class="logo">
    <img src="<?php echo base_url(); ?>images/logo.jpg" alt="Restaurant logo" style="width:50%;" >
</section>
