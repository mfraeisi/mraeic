<?php

echo '<table id = "table">';
echo '<caption>منوی غذا</caption>';
echo form_open('OrderAppController/AddOrder');
foreach ($foods->result() as $food) {
    echo '<tr><td>' . $food->FoodName . '</td>';
    echo '<td id="pricetd">' . $food->FoodPrice . '</td>';
    echo '<td id="buttons"><center><a id="foodreserve' . $food->FoodID . '" 
    class="resbutton" onclick="document.getElementById(';
    echo "'foodreserve";
    echo $food->FoodID . "').style.display='none', 
    document.getElementById('foodnum" . $food->FoodID . "').style.display = 'inline',  
    document.getElementById('foodcancel" . $food->FoodID . "').style.display = 'inline'";
    echo '">سفارش</a><select id="foodnum' . $food->FoodID . '" name="foodnum'
    . $food->FoodID . '" style="display:none"></select>
    <a id="foodcancel' . $food->FoodID . '" class="cancelbutton" onclick="document.getElementById(';
    echo "'foodcancel" . $food->FoodID . "').style.display='none',
    document.getElementById('foodnum" . $food->FoodID . "').style.display='none',
    document.getElementById('foodreserve" . $food->FoodID . "').style.display='block',
    FCancelReserve(" . $food->FoodID . ")";
    echo '">لغو</a></center></td>';
    echo "</tr>";
    $nums[] = 'foodnum' . $food->FoodID;
}
echo '</table>';
echo '<section id="buttons">';
echo '<a id="BackButton" href="BackToRegister">بازگشت</a>';
echo '<input type="submit" id="submit" value="صورت حساب">';
echo '</form>';
echo '</section>';

?>
<script type='text/javascript'>
       var nums = <?php echo json_encode($nums); ?>;
</script>
<script type='text/javascript' src="<?php echo base_url(); ?>js/FoodNumber.js"></script>
<script type='text/javascript' src="<?php echo base_url(); ?>js/CancelReserve.js"></script>