<section class="regform">
    <?php echo form_open('OrderAppController/AddCustomer') ?>
        <input type="text" id="CustomerRegName" name="CustomerRegName" placeholder="نام خود را وارد کنید" required
          oninvalid="this.setCustomValidity('لطفا نام خود را وارد نمایید')" oninput="setCustomValidity('')" autofocus /><br />
        <input type="number" id="Table" name="Table" placeholder="شماره میز خود را وارد کنید" required
          oninvalid="this.setCustomValidity('لطفا شماره میز خود را وارد نمایید')" oninput="setCustomValidity('')" /><br />
        <input type="submit" name="submit" id="submit" value="بعدی" style="width:100%; margin:25px 2px; padding:10px 20px;" />
    </form>
</section>
