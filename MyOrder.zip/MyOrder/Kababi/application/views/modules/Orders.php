<?php

$TotalPrice = 0;
$Price = 0;

echo '<section class="OrdersTable">';
foreach($Customers->result() as $Customer) {
  if($Customer->CustomerID != 0){
    echo '<table id="table">';
    echo '<tr id="CustomerRow"><th>نام مشتری</th><th>شماره تلفن</th><th>مبلغ خرید</th><th></th><th></th></tr>';
    echo form_open('CashierAppController/UpdateCustomer');
    echo '<tr><td><input type="text" name="CustomerName" value="' . $Customer->CustomerName . '" ></td>';
    echo '<td><input type="number" name="CustomerPhone" value="' . $Customer->CustomerPhone . '" ></td>';
    echo '<input type="hidden" name="CustomerID" value="' . $Customer->CustomerID . '" >';
    foreach($orders->result() as $order) {
        if($order->CustomerID == $Customer->CustomerID) {
            foreach($foods->result() as $food) {
                if($food->FoodID == $order->FoodID) {
                    $Price = $order->FoodNumber * $food->FoodPrice;
                    $TotalPrice += $Price;
                    $OrderRow = array (
                            $food->FoodName,
                            $order->FoodNumber,
                            $Price,
                            $order->OrderID
                        );
                    $OrdersArray[] = $OrderRow;
                    break;
            }
        }
    }
}
    echo '<td>';
    if($Customer->PaymentState == 0){
        echo '<select name="CustomerPayment" style="background-color: #ff4d4d;">';
    }else {
        echo '<select name="CustomerPayment" style="background-color: #00cc99;">';
    }
    echo '<option value="' . $Customer->PaymentState . '" >' . $TotalPrice . '</option>';
    echo '<option value="1">پرداخت شد</option>';
    echo '<option value="0">عدم پرداخت</option>';
    echo '</select></td>';
    echo '<td><button type="submit" name="UpdateCustomer" value="Save" >ثبت</button></td>';
    echo '<td><button type="submit" name="DeleteCustomer" value="Delete" >حذف</button></td>';
    echo form_close();
    $TotalPrice = 0;
    echo '<tr id="BillRow"><th>شرح غذا</th><th>تعداد</th><th>قیمت</th><th></th><th></th></tr>';
    foreach($OrdersArray as $row) {
        echo '<tr>';
        echo '<td>' . $row[0] . '</td>';
        echo form_open('CashierAppController/UpdateOrder');
            echo '<td id="FoodNumber"><input type="number" name="FoodNumber" value="' . $row[1] . '" ></td>';
            echo '<input type="hidden" name="OrderID" value="' . $row[3] . '" >';
            echo '<td>' . $row[2] . '</td>';
            echo '<td><button type="submit" name="UpdateOrderNumber" value="Save" >ثبت</button></td>';
            echo '<td><button type="submit" name="DeleteOrder" value="Delete" >حذف</button></td>';
        echo form_close();
        echo '</tr>';
    }
    $OrdersArray = array();
    echo form_open('CashierAppController/AddOrder');
        echo '<tr><td><select name="FoodID">';
        echo '<option value="caption"></option>';
        foreach($foods->result() as $food) {
            echo '<option value="' . $food->FoodID . '">' . $food->FoodName . '</option>';
        }
        echo '</select></td>';
        echo '<td><input type="number" name="FoodNumber"></td>';
        echo '<input type="hidden" name="CustomerID" value="' . $Customer->CustomerID . '" >';
        echo '<td></td><td><input type="submit" name="AddOrder" value="ثبت"></td></tr>';
    echo form_close();
    echo '</table>';
}
}
echo '</section>';

?>
