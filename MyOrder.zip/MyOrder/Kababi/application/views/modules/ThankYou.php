<section class="ThankYou">
<p>با تشکر از انتخاب شما</p>
</section>