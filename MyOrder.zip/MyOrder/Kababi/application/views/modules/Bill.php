<?php

$Price = 0;
$TotalPrice = 0;

foreach($Customers->result() as $Customer)  {
    if($Customer->CustomerName == $_SESSION['CustomerName'] && $Customer->CustomerTable == $_SESSION['CustomerTable']) {
        $CustomerID = $Customer->CustomerID;
    }
}

echo '<table id="Bill">';
echo '<tr><th>غذا</th><th>تعداد</th><th>قیمت</th></tr>';
echo form_open('OrderAppController/Confirm');
foreach($orders->result() as $order) {
    if($order->CustomerID == $CustomerID) {
        foreach($foods->result() as $food) {
            if($food->FoodID == $order->FoodID) {
                echo '<tr><td>' . $food->FoodName . '</td>';
                echo '<td>' . $order->FoodNumber . '</td>';
                $Price = $order->FoodNumber * $food->FoodPrice;
                $TotalPrice += $Price;
                echo '<td>' . $Price . '</td></tr>';
            }
        }
    }     
}
echo '<tr><td></td><td><b>جمع کل</b></td><td><b><I>' . $TotalPrice . '</I></b></td></tr>';
echo '</table>';
echo '<section id="buttons">';
echo '<a id="BackButton" href="BackToMenu">سفارش مجدد</a>';
echo '<input type="submit" id="submit" value="ثبت نهایی">';
echo '</form>';
echo '</section>';
 
?>