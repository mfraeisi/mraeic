<?php

echo '<section class="FoodsTable">';
echo '<table id="table">';
echo '<tr><th>شرح غذا</th><th>قیمت</th><th></th></tr>';
foreach($foods->result() as $food) {
    echo '<tr><td>' . $food->FoodName . '</td>';
    echo form_open('CashierAppController/UpdateFoodPrice');
    echo '<td><input type="number" name="Price" step="500" min="0" value="' . $food->FoodPrice . '" ></td>';
    echo '<input type="hidden" name="FoodID" value="' . $food->FoodID . '">';
    echo '<td><input type="submit" id="UpdateFoodPrice" value="ثبت" ></td>';
    echo form_close();
    echo form_open('CashierAppController/DeleteFood');
    echo '<input type="hidden" Name="FoodID" value="' . $food->FoodID . '">';
    echo '<td><input type="submit" name="DeleteFood" value="حذف"></td></tr>';
    echo form_close();
}

echo form_open('CashierAppController/AddFood');
echo '<tr><td><input type="text" id="AddFoodName" name="AddFoodName" placeholder="نام غذا را وارد کنید" required autofocus ></td>';
echo '<td><input type="number" id="AddFoodPrice" name="AddFoodPrice" min="0" step="500" placeholder="قیمت را وارد کنید" required ></td>';
echo '<td><select name="AddFoodType">';
echo '<option value=0>غذا</option>';
echo '<option value=1>نوشیدنی</option>';
echo '</select></td>';
echo '<td><input type="submit" Name="Submit" value="ثبت"></td></tr>';
echo '</table>';
echo form_close();
echo '</section>';

?>