<section class="login">
    <?php echo form_open('CashierAppController/Login_Process') ?>
        <input type="text" id="UserName" name="UserName" placeholder="نام کاربری" required
          oninvalid="this.setCustomValidity('لطفا نام کاربری خود را وارد نمایید')" oninput="setCustomValidity('')" autofocus /><br />
        <input type="password" id="Password" name="Password" placeholder="رمز عبور" required
          oninvalid="this.setCustomValidity('لطفا رمز عبور خود را وارد نمایید')" oninput="setCustomValidity('')" /><br />
        <input type="submit" name="Login" id="Login" value="ورود" style="width:100%; margin:25px 2px; padding:10px 20px;" />
    </form>
</section>
