<?php

echo '<section class="Reports">';

$TotalNumber = 0;
$TotalPayment = 0;
echo '<table id="table">';
echo '<tr><th>شرح غذا</th><th>تعداد فرخته شده</th><th>جمع پرداختی</th></tr>';
foreach($reports->result() as $report) {
    echo '<tr>';
    echo '<td>' . $report->FoodName . '</td>';
    echo '<td><input type="number" id="UpdateReportNumber" value="' . $report->Number . '" style="width:30%"></td>';
    echo '<td><input type="number" id="UpdateReportTotalPrice" value="' . $report->TotalPrice . '" style="width:30%"></td>';
    echo '</tr>';

    $TotalNumber += $report->Number;
    $TotalPayment += $report->TotalPrice;
}

echo '<tr>';
echo '<th>مجموع</th>';
echo '<th>' . $TotalNumber . '</th>';
echo '<th>' . $TotalPayment . '</th>';
echo '</tr>';
echo '</table>';

echo "<p>تاریخ:";
echo '<input type="text" id="datepicker" disabled/></p>';
echo '<button name="Archive">ثبت در بایگانی </button>';
echo '</br>';

echo '</section>';

?>