<section class="UserAccount">
    <?php 
    $user = $users->row();
        echo form_open('CashierAppController/UserAccountSubmit');
        echo '<p><b>تغییرات حساب کاربری</b></p>';
        echo '<p style="color: red;">رمز عبور خود را به گونه انتخاب نمایید که قابل حدس زدن نباشد</p>';
        echo '<center>';
        echo '<input type = "text" name = "AccountFullName" value = "' . $user->FullName . '" disabled style = "display:block">';
        echo '<input type = "text" name = "AccountUsername" placeholder = "نام کاربری جدید" style = "display:block">';
        echo '<input type = "password" name = "AccountPassword" placeholder = "رمز عبور جدید" style = "display:block">';
        echo '<input type = "password" name = "AccountPassConf" placeholder = "تکرار رمز عبور جدید" style = "display:block">';
        echo '<input type = "submit" name = "Submit"  value = "ثبت تغییرات" >';
        echo '</center>';
        echo form_close();
    ?>
</section>