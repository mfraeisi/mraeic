<section class="CashierMenu">
    <nav>
        <ul>
            <li id="nav"><a href="Orders">سفارشات</a></li>
            <li id="nav"><a href="Foods">منوی غذا</a></li>
            <li id="nav"><a href="Report">گزارش روزانه</a></li>
            <li id="nav"><a href="Report">بایگانی گزارشات</a></li>
            <li id="nav"><a href="UserAccount">حساب کاربری</a></li>
            <li id="user"><a href="logout"><?php echo '[خروج]'; ?></a></li>
            <li id="user"><?php echo $_SESSION['FullName']; ?></li>
        </ul>
    </nav>
</section>