<?php

class AppModel extends CI_Model {

    public function __construct() {
        $this->load->database();
        $this->load->helper('security');
        $this->load->library('session');
    }

    public function get_foods() {
        $this->db->order_by('FoodType asc ,FoodID asc');
        $query = $this->db->get('food_menu');
        return $query;
    }

    public function get_foods_where($FoodID) {
        $this->db->where('FoodID', $FoodID);
        $query = $this->db->get('food_menu');
        return $query;
    }

    public function get_customers() {
        $this->db->order_by('PaymentState asc');
        $query = $this->db->get('Customers');
        return $query;
    }

    public function get_customers_where($CustomerID) {
        $this->db->where('CustomerID', $CustomerID);
        $this->db->order_by('PaymentState asc');
        $query = $this->db->get('Customers');
        return $query;
    }

    public function get_users() {
        $query = $this->db->get('users');
        return $query;
    }

    public function get_users_where($UserID) {
        $this->db->where('UserID', $UserID);
        $query = $this->db->get('users');
        return $query;
    }

    public function get_reports() {
        $query = $this->db->get('reports');
        return $query;
    }

    public function insert_food($Food) {
        $this->db->insert('food_menu', $Food);
    }

    public function insert_customer($Customer)  {
        $this->db->insert('customers', $Customer);
    }

    public function insert_order($Order) {
        $this->db->insert('orders', $Order);
    }

    public function insert_report($Report) {
        $this->db->insert('reports', $Report);
    }

    public function get_orders_where($CustomerID) {
        $this->db->where('CustomerID', $CustomerID);
        $query = $this -> db->get('orders');
        return $query;
    }

    public function get_orders() {
        $query = $this -> db->get('orders');
        return $query;
    }

    public function delete_food($FoodID) {
        $this->db->where('FoodID', $FoodID);
        $this->db->delete('food_menu');

        $this->db->where('FoodID', $FoodID);
        $this->db->delete('orders');
    }

    public function delete_customer($CustomerID) {
        $this->db->where('CustomerID', $CustomerID);
        $this->db->delete('customers');
    }

    public function delete_orders($CustomerID) {
        $this->db->where('CustomerID', $CustomerID);
        $this->db->delete('orders');
    }

    public function delete_order($OrderID) {
        $this->db->where('OrderID', $OrderID);
        $this->db->delete('orders');
    }

    public function update_customer($Update, $CustomerID) {
        $this->db->where('CustomerID', $CustomerID);
        $this->db->update('customers', $Update);
    }

    public function update_food($Update, $FoodID) {
        $this->db->where('FoodID', $FoodID);
        $this->db->update('food_menu', $Update);
    }

    public function update_order($Update, $OrderID) {
        $this->db->where('OrderID', $OrderID);
        $this->db->update('orders', $Update);
    }

    public function update_report($Update, $ReportID) {
        $this->db->where('ReportID', $ReportID);
        $this->db->update('reports', $Update);
    }

    public function add_order($Order, $FoodID) {
        $this->db->where('FoodID', $FoodID);
        $this->db->insert('orders', $Order);
    }

    public function UserAccountUpdate($UpdateAccount, $UserID) {
        $this->db->where('UserID', $UserID);
        $this->db->update('users', $UpdateAccount);
    }

    public function LoginModel($UserName, $Password) {
        $query = $this->db->get('users');

        foreach($query->result() as $row) {
            $PasswordVerify = password_verify($Password, $row->Password);

            if($row->UserName == $UserName && $PasswordVerify) {
                $User = array(
                    'UserID' => $row->UserID,
                    'UserName' => $row->UserName,
                    'FullName' => $row->FullName
                );
                $this->session->set_userdata($User);
                return true;
            }
        }
        return false;
    }

}

?>
