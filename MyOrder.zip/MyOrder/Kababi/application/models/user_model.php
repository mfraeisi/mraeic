<?php

defined('BASEPATH') OR exit('No direct script access allowed');



/**

*

*/

class User_model extends CI_Model

{

public function read(){

   

       $query = $this->db->query("select * from `users`");

       return $query->result_array();

   }



   public function insert($data){

       

       $this->UserName    = $data['UserName ']; // please read the below note

       $this->Password  = $data['Password'];



       if($this->db->insert('users',$this))

       {    

           return 'Data is inserted successfully';

       }

         else

       {

           return "Error has occured";

       }

   }



   public function update($id,$data){

   

      $this->UserName    = $data['UserName']; // please read the below note

       $this->Password  = $data['Password'];

       $result = $this->db->update('users',$this,array('user_id' => $id));

       if($result)

       {

           return "Data is updated successfully";

       }

       else

       {

           return "Error has occurred";

       }

   }



   public function delete($id){

   

       $result = $this->db->query("delete from `users` where user_id = $id");

       if($result)

       {

           return "Data is deleted successfully";

       }

       else

       {

           return "Error has occurred";

       }

   }



}
