<?php

    class CashierAppController extends CI_Controller {
        public function __construct() {
            parent::__construct();
            $this->load->model('AppModel');
            $this->load->helper('url');
            $this->load->library('form_validation');
        }

        public function Orders() {
            if(! $_SESSION['FullName']) {
                    redirect('CashierAppController/Login');
            }

            $data['Customers'] = $this->AppModel->get_customers();
            $data['foods'] = $this->AppModel->get_foods();
            $data['orders'] = $this->AppModel->get_orders();
            $data['title'] = 'سفارشات';
            $data['cssfile'] = 'CashierApp';

            $this->load->view('templates/header', $data);
            $this->load->view('modules/CashierMenu');
            $this->load->view('modules/Orders');
            $this->load->view('templates/footer');
        }

        public function Foods() {
            if(! $_SESSION['FullName']) {
                    redirect('CashierAppController/Login');
            }

            $data['foods'] = $this->AppModel->get_foods();
            $data['title'] = 'غذاها';
            $data['cssfile'] = 'CashierApp';

            $this->load->view('templates/header', $data);
            $this->load->view('modules/CashierMenu');
            $this->load->view('modules/AddRemoveFood', $data);
            $this->load->view('templates/footer');
        }

        public function AddFood() {
            $Food = array(
                'FoodName' => $this->input->post('AddFoodName'),
                'FoodPrice' => $this->input->post('AddFoodPrice'),
                'FoodType' => $this->input->post('AddFoodType')
            );

            $this->AppModel->insert_food($Food);
            redirect('CashierAppController/Foods');
        }

        public function AddOrder() {
            $Order = array(
                'CustomerID' => $this->input->post('CustomerID'),
                'FoodID' => $this->input->post('FoodID'),
                'FoodNumber' => $this->input->post('FoodNumber')
            );

            $this->AppModel->add_order($Order, $FoodID);
            redirect('CashierAppController/Orders');
        }

        public function DeleteFood() {
            $FoodID = $this->input->post('FoodID');

            $this->AppModel->delete_food($FoodID);
            redirect('CashierAppController/Foods');
        }

        public function UpdateFoodPrice() {
            $Update = array(
                'FoodID' => $this->input->post('FoodID'),
                'FoodPrice' => $this->input->post('Price')
            );
            $FoodID = $this->input->post('FoodID');

            $this->AppModel->update_food($Update, $FoodID);
            redirect('CashierAppController/Foods');
        }

        public function UpdateOrder() {
            if($this->input->post('UpdateOrderNumber') == "Save") {
                $Update = array(
                        'OrderID' => $this->input->post('OrderID'),
                        'FoodNumber' => $this->input->post('FoodNumber')
                );
                $OrderID = $this->input->post('OrderID');

                $this->AppModel->update_order($Update, $OrderID);
                redirect('CashierAppController/Orders');
            }

            if($this->input->post('DeleteOrder') == "Delete") {
                $OrderID = $this->input->post('OrderID');

                $this->AppModel->delete_order($OrderID);
                redirect('CashierAppController/Orders');
            }
        }

        public function UpdateCustomer() {
            if($this->input->post('UpdateCustomer') == "Save") {
                $Update = array(
                        'CustomerID' => $this->input->post('CustomerID'),
                        'CustomerName' => $this->input->post('CustomerName'),
                        'CustomerTable' => $this->input->post('CustomerTable'),
                        'PaymentState' => $this->input->post('CustomerPayment')
                );
                $CustomerID = $this->input->post('CustomerID');

                $this->AppModel->update_customer($Update, $CustomerID);

/****************************Reports Page DataBase**************************************/

                $Customers = $this->AppModel->get_customers_where($CustomerID);
                $Customer = $Customers->row();

                if($Customer->PaymentState == 1) {

                        $orders = $this->AppModel->get_orders_where($CustomerID);

                        $reports = $this->AppModel->get_reports();

                        foreach($orders->result() as $order) {
                                $foods = $this->AppModel->get_foods_where($order->FoodID);
                                $food = $foods->row();
                                if($order->Reported == 0) {
                                        foreach($reports->result() as $report) {
                                                if($food->FoodName == $report->FoodName) {
                                                        $Number = $order->FoodNumber + $report->Number;
                                                        $price = ($food->FoodPrice)*($order->FoodNumber) + $report->TotalPrice;
                                                        $Update = array(
                                                                'Number' => $Number,
                                                                'TotalPrice' => $price
                                                                );
                                                        $this->AppModel->update_report($Update, $report->ReportID);

                                                        $UpdateOrder = array(
                                                                'Reported' => 1
                                                                );
                                                        $this->AppModel->update_order($UpdateOrder, $order->OrderID);
                                                        goto NextOrder;
                                                }
                                        }
                                        $price = ($food->FoodPrice)*($order->FoodNumber);
                                        $Report = array(
                                                'Date' => date("Y-m-d"),
                                                'FoodName' => $food->FoodName,
                                                'Number' => $order->FoodNumber,
                                                'TotalPrice' => $price
                                                );

                                        $this->AppModel->insert_report($Report);

                                        $UpdateOrder = array(
                                                'Reported' => 1
                                                );

                                        $this->AppModel->update_order($UpdateOrder,$order->OrderID);
                                }
                        NextOrder:;
                        }

                }

                if($Customer->PaymentState == 0) {

                        $orders = $this->AppModel->get_orders_where($CustomerID);

                        foreach($orders->result() as $order) {
                                if($order->Reported == 1) {
                                        $foods = $this->AppModel->get_foods_where($order->FoodID);
                                        $food = $foods->row();
                                        $reports = $this->AppModel->get_reports();
                                        foreach($reports->result() as $report) {
                                                if($food->FoodName == $report->FoodName) {
                                                        $Number = $report->Number - $order->FoodNumber;
                                                        $price = $report->TotalPrice - ($food->FoodPrice)*($order->FoodNumber);
                                                        $Update = array(
                                                                'Number' => $Number,
                                                                'TotalPrice' => $price
                                                                );
                                                        $this->AppModel->update_report($Update, $report->ReportID);
                                                        $UpdateOrder = array(
                                                                'Reported' => 0
                                                                );
                                                        $this->AppModel->update_order($UpdateOrder, $order->OrderID);
                                                }
                                        }
                                }

                        }
                }

/*************************************************************************************/

                redirect('CashierAppController/Orders');
            }

            if($this->input->post('DeleteCustomer') == "Delete") {
                $CustomerID = $this->input->post('CustomerID');

                $this->AppModel->delete_customer($CustomerID);
                $this->AppModel->delete_orders($CustomerID);
                redirect('CashierAppController/Orders');
            }

        }

        public function Login() {
                $data['title'] = 'ورود';
                $data['cssfile'] = 'CashierApp';

                $this->load->view('templates/header', $data);
                $this->load->view('modules/logo');
                $this->load->view('modules/Login');
                $this->load->view('templates/footer');
        }

        public function Login_Process()  {
                $UserName = $this->security->xss_clean($this->input->post('UserName'));
                $Password = $this->security->xss_clean($this->input->post('Password'));

                $result = $this->AppModel->LoginModel($UserName, $Password);

                if(! $result) {
                        redirect('CashierAppController/Login');
                }else{
                        redirect('CashierAppController/Orders');
                }

        }

        public function Report() {
                if(! $_SESSION['FullName']) {
                    redirect('CashierAppController/Login');
                }

                $data['title'] = 'گزارش';
                $data['cssfile'] = 'CashierApp';
                $data['foods'] = $this->AppModel->get_foods();
                $data['reports'] = $this->AppModel->get_reports();

                $this->load->view('templates/header', $data);
                $this->load->view('modules/CashierMenu');
                $this->load->view('modules/Report');
                $this->load->view('templates/footer');
        }

        public function UserAccount() {
                if(! $_SESSION['FullName']) {
                    redirect('CashierAppController/Login');
                }

                $UserID = $_SESSION['UserID'];

                $data['title'] = 'حساب کاربری';
                $data['cssfile'] = 'CashierApp';
                $data['users'] = $this->AppModel->get_users_where($UserID);

                $this->load->view('templates/header', $data);
                $this->load->view('modules/CashierMenu');
                $this->load->view('modules/UserAccount', $data);
                $this->load->view('templates/footer');
        }

        public function UserAccountSubmit() {
                $UserID = $_SESSION['UserID'];

                $data['title'] = 'حساب کاربری';
                $data['cssfile'] = 'CashierApp';
                $data['users'] = $this->AppModel->get_users_where($UserID);

                $this->form_validation->set_rules('AccountUsername','نام کاربری','required');
                $this->form_validation->set_rules('AccountPassword','رمز عبور','required');
                $this->form_validation->set_rules('AccountPassConf','تایید رمز عبور',
                'required|matches[AccountPassword]',array('required' => 'عدم تطابق')
                );

                if ($this->form_validation->run() == FALSE) {
                        $this->load->view('templates/header', $data);
                        $this->load->view('modules/CashierMenu');
                        $this->load->view('modules/UserAccount', $data);
                        $this->load->view('templates/footer');
                }
                else
                {
                        $Password = $this->input->post('AccountPassword');
                        $HashedPassword = password_hash($Password, PASSWORD_DEFAULT);

                        $UpdateAccount = array(
                                        'UserName' => $this->input->post('AccountUsername'),
                                        'Password' => $HashedPassword
                        );
                        $this->AppModel->UserAccountUpdate($UpdateAccount, $UserID);

                        $this->load->view('modules/CashierMenu');
                        $this->load->view('templates/header', $data);
                        $this->load->view('modules/formsuccess');
                        $this->load->view('templates/footer');
                }
        }

        public function logout() {
                $this->session->sess_destroy();
                redirect('CashierAppController/Login');
        }

    }

?>
