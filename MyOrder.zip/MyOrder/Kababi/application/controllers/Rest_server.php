<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';

class Rest_server extends REST_Controller {
    function __construct() {
      parent::__construct();
      $this->load->model('AppModel');
    }

    public function foods_get()
    {
        $menu = $this->AppModel->get_foods();
        $this->set_response($menu);
    }

    public function customers_get()
    {
        $customers = $this->AppModel->get_customers();
        $this->set_response($customers);
    }

    public function orders_get()
    {
        $orders = $this->AppModel->get_orders();
        $this->set_response($orders);
    }

    public function customer_put()
    {
        $data = $this->input->input_stream();
        $this->AppModel->insert_customer($data);
    }

    public function orders_put()
    {
        $data = $this->input->input_stream();
        $this->AppModel->insert_order($data);
    }
}
