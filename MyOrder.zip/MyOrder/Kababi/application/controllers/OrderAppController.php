<?php

class OrderAppController extends CI_Controller
{
  public function __construct()
  {
      parent::__construct();
      $this->load->helper('form');
      $this->load->model('AppModel');
      $this->load->library('session');
      $this->load->helper('url');
  }

  public function Register()
  {
    $data['title'] = 'ورود مشتری';
    $data['cssfile'] = 'OrderApp';

    $this->load->view('templates/header', $data);
    $this->load->view('modules/logo');
    $this->load->view('modules/regform');
    $this->load->view('templates/footer');
  }

  public function AddCustomer() {    
    $Customer = array(
        'CustomerName' => $this->input->post('CustomerRegName'),
        'CustomerTable' => $this->input->post('Table')
    );
    $this->session->set_userdata($Customer);
  
    $this->AppModel->insert_customer($Customer);

    $data['Customers'] = $this->AppModel->get_customers();
    foreach($data['Customers']->result() as $Customer)  {
      if($Customer->CustomerName == $_SESSION['CustomerName'] && $Customer->CustomerTable == $_SESSION['CustomerTable']) {
        $_SESSION['CustomerID'] = $Customer->CustomerID;
      }
    }

    redirect('OrderAppController/Menu');
  }

  public function Menu() {
    $data['foods'] = $this->AppModel->get_foods();
    $data['title'] = 'منوی غذا';
    $data['cssfile'] = 'OrderApp';

    $this->load->view('templates/header', $data);
    $this->load->view("modules/Customers");
    $this->load->view('modules/FoodMenu', $data);
    $this->load->view('templates/footer');
  }

  public function AddOrder() {
    $post = $this->input->post();

    $data['foods'] = $this->AppModel->get_foods(); 

    foreach($data['foods']->result() as $food) {
    $FoodNumber = $_POST['foodnum' . $food->FoodID];
    if($FoodNumber == 0) {
        goto NextFood;
    }
    $Order = array(
        'CustomerID' => $_SESSION['CustomerID'],
        'FoodID' => $food->FoodID ,
        'FoodNumber' => $FoodNumber
    );
    $this->AppModel->insert_order($Order); 
    NextFood:;  
    }

    redirect('OrderAppController/Bill');
  }

  public function Bill() {
    $data['Customers'] = $this->AppModel->get_customers();
    $data['foods'] = $this->AppModel->get_foods(); 
    $data['orders'] = $this->AppModel->get_orders();
    $data['title'] = 'صورت حساب';
    $data['cssfile'] = 'OrderApp';    

    $this->load->view('templates/header', $data);
    $this->load->view("modules/Customers");
    $this->load->view('modules/Bill', $data);
    $this->load->view('templates/footer');
  }

  public function Confirm() {
    $data['title'] = 'تایید نهایی';
    $data['cssfile'] = 'OrderApp';
    $this->session->sess_destroy();

    $this->load->view('templates/header', $data);
    $this->load->view("modules/ThankYou");
    $this->load->view('templates/footer');
  }

  public function BackToRegister() {
    $this->AppModel->delete_customer($_SESSION['CustomerID']);
    $this->session->sess_destroy();
    redirect('OrderAppController/Register');
  }

  public function BackToMenu() {
    $this->AppModel->delete_orders($_SESSION['CustomerID']);
    redirect('OrderAppController/Menu');
  }
  
  public function php_info() {
	  phpinfo();
  }

}

?>